import React from 'react';

// 💡 引数に requests = [] を追加して、依頼履歴から正しい作業者を逆引きできるようにします
function MccbCard({ mccb, borrowedCount, onSelect, onToggleFavorite, requests = [] }) {
  
  // 💡 改善ロジック：この設備、またはこの設備を代替しているダミー札で作業している人を「依頼履歴」から正確に抽出
  const activeWorkers = React.useMemo(() => {
    const workersMap = new Map();

    requests.forEach(req => {
      if (!req.reservedCards) return;
      
      // 依頼に紐づく全ての確保情報を走査
      Object.keys(req.reservedCards).forEach(originalMccbId => {
        const resInfo = req.reservedCards[originalMccbId];
        if (!resInfo) return;

        // パターンA: このカードが通常設備で、本人の札 or 代替ダミー札が使われているとき
        // パターンB: このカードがダミー設備自体で、実際にその番号の札がロックされているとき
        if (originalMccbId === mccb.id || resInfo.actualMccbId === mccb.id) {
          if (req.workerName) {
            // 重複を避けるためキーを「作業者名-札番号」にしてストック
            workersMap.set(`${req.workerName}-${resInfo.cardNo}`, {
              id: resInfo.cardNo,
              workerName: req.workerName,
              // ダミー札で作業している場合はそれと分かるバッジ用フラグ
              isAlternative: resInfo.actualMccbId !== originalMccbId
            });
          }
        }
      });
    });

    return Array.from(workersMap.values());
  }, [mccb.id, requests]);

  const categoryColors = {
    '1スト': 'bg-white text-gray-900 border-gray-350 shadow-sm',
    '2スト': 'bg-black text-white border-black',
    '3スト': 'bg-red-600 text-white border-red-600',
    '4スト': 'bg-blue-600 text-white border-blue-600',
    '5スト': 'bg-yellow-400 text-gray-900 border-yellow-400',
    '6スト': 'bg-green-600 text-white border-green-600',
    '共通': 'bg-gray-100 text-gray-700 border-gray-300',
  };

  const badgeColor = categoryColors[mccb.category] || 'bg-gray-50 text-gray-600 border-gray-200';

  return (
    <div
      onClick={onSelect}
      className={`bg-white p-4 rounded-xl border shadow-sm relative flex flex-col justify-between min-h-[140px] transition-all duration-200 hover:shadow-md hover:border-gray-300 cursor-pointer ${
        mccb.isPowerOff ? 'border-red-500 bg-red-50/10' : 'border-gray-200'
      }`}
    >
      <button
        onClick={(e) => {
          e.stopPropagation(); 
          onToggleFavorite();
        }}
        className={`absolute top-3 right-3 text-lg transition-all transform hover:scale-125 focus:outline-none ${
          mccb.isFavorite ? 'text-amber-500 font-bold drop-shadow-sm' : 'text-gray-300 hover:text-amber-400'
        }`}
        title={mccb.isFavorite ? "お気に入り解除" : "お気に入り登録"}
      >
        {mccb.isFavorite ? '★' : '☆'}
      </button>

      <div>
        <div className="flex items-center gap-1.5 mb-1.5">
          <span className="text-[10px] text-gray-400 bg-gray-50 border border-gray-200 px-1.5 py-0.5 rounded font-bold">
            {mccb.room}
          </span>
          <span className={`text-[10px] px-1.5 py-0.5 rounded border font-black ${badgeColor}`}>
            {mccb.category}
          </span>
        </div>
        <h3 className="text-sm font-black text-gray-800 leading-snug line-clamp-2 mb-2 pr-6">
          {mccb.name}
        </h3>
      </div>

      <div className="flex items-center justify-between gap-2 pt-2 border-t border-gray-100 text-xs font-bold">
        {mccb.isPowerOff ? (
          <>
            <span className="text-red-600 flex items-center gap-1 shrink-0">
              🛑 操作禁止
            </span>
            <span className="text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200 font-mono">
              子札: {borrowedCount} 枚
            </span>
          </>
        ) : (
          <>
            <span className="text-green-600 flex items-center gap-1">
              🟢 通常送電
            </span>
            <span className="text-gray-400 font-normal">―</span>
          </>
        )}
      </div>

      {/* 💡 改善された現在の作業者一覧エリア（ねじれを完全解消） */}
      {activeWorkers.length > 0 && (
        <div className="mt-2.5 pt-2 border-t border-dashed border-gray-200">
          <p className="text-[10px] text-gray-400 font-bold mb-1">🛠️ 現在の作業者:</p>
          <div className="flex flex-wrap gap-1">
            {activeWorkers.map((card, idx) => (
              <span
                key={`${card.workerName}-${idx}`}
                className={`text-[10px] px-2 py-0.5 rounded font-medium flex items-center gap-1 ${
                  card.isAlternative 
                    ? 'bg-amber-50 text-amber-800 border border-amber-200' // 代替ダミー札使用時はオレンジ色の警告
                    : 'bg-gray-100 text-gray-700 border border-gray-200'
                }`}
              >
                <span className="font-mono text-[9px] opacity-60">No.{card.id}</span>
                {card.workerName}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default MccbCard;