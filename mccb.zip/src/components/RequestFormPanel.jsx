import { useState } from 'react';
import PrintPreviewForm from './PrintPreviewForm'; 

export default function RequestFormPanel({ mccbList, onAddRequest, requests = [], deviceGroups = [] }) {
  const [workerName, setWorkerName] = useState('');
  const [workContent, setWorkContent] = useState('');
  const [selectedMccbIds, setSelectedMccbIds] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');

  // 💡 【新機能】ダミー設備ごとの代替名称入力状態を管理
  const [dummyNames, setDummyNames] = useState({});

  // 設備チェックボックスの選択・解除
  const handleToggleMccb = (id) => {
    if (selectedMccbIds.includes(id)) {
      setSelectedMccbIds(selectedMccbIds.filter(item => item !== id));
    } else {
      setSelectedMccbIds([...selectedMccbIds, id]);
    }
  };

  // グループボタンが押されたときの一括選択・解除処理
  const handleSelectGroup = (groupMccbIds) => {
    if (!groupMccbIds || groupMccbIds.length === 0) return;
    const isAllSelected = groupMccbIds.every(id => selectedMccbIds.includes(id));
    if (isAllSelected) {
      setSelectedMccbIds(selectedMccbIds.filter(id => !groupMccbIds.includes(id)));
    } else {
      const newSelection = Array.from(new Set([...selectedMccbIds, ...groupMccbIds]));
      setSelectedMccbIds(newSelection);
    }
  };

  // 印刷・依頼発行実行
  const handlePrint = () => {
    if (!workerName.trim()) {
      alert('作業者名を入力してください。');
      return;
    }
    if (selectedMccbIds.length === 0) {
      alert('設備が選択されていません。');
      return;
    }

    if (onAddRequest) {
      onAddRequest({
        id: `REQ-${Date.now()}`,
        timestamp: new Date().toLocaleString('ja-JP'),
        workerName: workerName,
        workContent: workContent,
        targetMccbIds: selectedMccbIds,
        dummyNames: dummyNames // 💡 【新機能】代替設備名オブジェクトを内包させて発行
      });
      alert('停電依頼を発行し、一覧へ登録しました。');
    }
    window.print();
  };

  // 🔍 設備検索フィルター
  const filteredMccbList = mccbList.filter(mccb => 
    mccb.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    mccb.room.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex flex-col lg:flex-row gap-6 items-start print:block print:space-y-0 print:p-0">
      
      {/* 📝 左側：入力エリア＆設備選択 */}
      <div className="w-full lg:w-1/3 bg-white p-6 rounded-xl border border-gray-200 shadow-sm space-y-4 print:hidden shrink-0 lg:sticky lg:top-4">
        <h2 className="text-sm font-black text-gray-700 border-b pb-2">📝 停電依頼書の作成・印刷用フォーム</h2>
        
        <div className="space-y-3">
          <div>
            <label className="block text-xs text-gray-500 font-bold mb-1">作業責任者名 <span className="text-red-500">*</span></label>
            <input type="text" value={workerName} onChange={(e) => setWorkerName(e.target.value)} placeholder="例: 山田 太郎" className="border p-2 rounded text-sm w-full bg-gray-50 focus:bg-white focus:outline-none" />
          </div>
          <div>
            <label className="block text-xs text-gray-500 font-bold mb-1">作業内容・目的</label>
            <input type="text" value={workContent} onChange={(e) => setWorkContent(e.target.value)} placeholder="例: ○○ポンプ定期点検作業" className="border p-2 rounded text-sm w-full bg-gray-50 focus:bg-white focus:outline-none" />
          </div>
        </div>

        {/* グループ一括選択ショートカットスイッチ群 */}
        {deviceGroups && deviceGroups.length > 0 && (
          <div className="space-y-1.5 pt-1">
            <label className="block text-[11px] text-gray-400 font-bold">👥 グループ一括選択ショートカット</label>
            <div className="flex flex-wrap gap-1.5">
              {deviceGroups.map(group => {
                const groupIds = group.mccbIds || [];
                const isActive = groupIds.length > 0 && groupIds.every(id => selectedMccbIds.includes(id));
                return (
                  <button
                    key={group.id}
                    type="button"
                    onClick={() => handleSelectGroup(groupIds)}
                    className={`px-2.5 py-1.5 rounded text-[11px] font-black border transition-all cursor-pointer shadow-sm ${
                      isActive ? 'bg-blue-600 border-blue-700 text-white' : 'bg-white border-gray-300 text-gray-600 hover:bg-gray-50'
                    }`}
                  >
                    {isActive ? '✓ ' : '➕ '}{group.name}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        <div className="space-y-2 pt-1">
          <label className="block text-xs text-gray-500 font-bold">対象設備の選択（複数選択可）</label>
          <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="🔍 設備名や電気室で絞り込み..." className="border p-2 rounded text-xs w-full focus:outline-none mb-2" />
          
          {/* 💡 デザイン構造を維持しつつ、チェックされたダミーに入力欄を出すよう最適化 */}
          <div className="max-h-56 overflow-y-auto border rounded-lg p-2 bg-gray-50 space-y-1">
            {filteredMccbList.map(mccb => {
              const isSelected = selectedMccbIds.includes(mccb.id);
              const isDummy = mccb.isDummy || mccb.name.includes('ダミー');
              return (
                <div key={mccb.id} className={`p-2 rounded border transition-all ${
                  isSelected ? 'bg-blue-50/30 border-blue-200 text-blue-900 shadow-sm' : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-50'
                }`}>
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-bold">
                    <input type="checkbox" checked={isSelected} onChange={() => handleToggleMccb(mccb.id)} className="rounded text-blue-600 focus:ring-blue-500" />
                    <div className="truncate flex-1">
                      <span className="text-[9px] bg-gray-100 px-1.5 py-0.5 rounded text-gray-400 mr-1.5 border">{mccb.room}</span>
                      {mccb.name}
                    </div>
                  </label>
                  
                  {/* 💡 ダミー設備が手動選択された場合のみ、入力フォームを美しく展開 */}
                  {isSelected && isDummy && (
                    <div className="mt-1.5 pl-6">
                      <input
                        type="text"
                        value={dummyNames[mccb.id] || ''}
                        onChange={(e) => setDummyNames({ ...dummyNames, [mccb.id]: e.target.value })}
                        placeholder="✏️ 代替する実際の設備名称を入力"
                        className="border p-1.5 rounded text-[11px] w-full bg-white focus:outline-none font-medium text-gray-700 placeholder-gray-400 focus:border-blue-400 shadow-inner"
                        onClick={(e) => e.stopPropagation()} // ラベル開閉のバッティング防止
                      />
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        <div className="pt-2 text-right">
          <button onClick={handlePrint} className="bg-blue-600 hover:bg-blue-700 text-white font-black px-6 py-2.5 rounded-lg text-sm shadow-md cursor-pointer w-full">
            🖨️ 停電依頼を発行して印刷
          </button>
        </div>
      </div>

      {/* 右側：A4プレビュー帳票（手動入力欄 dummyNames をプロパティ追加） */}
      <PrintPreviewForm workerName={workerName} workContent={workContent} selectedMccbIds={selectedMccbIds} mccbList={mccbList} requests={requests} dummyNames={dummyNames} />
    </div>
  );
}