import MccbCard from './MccbCard';

export default function MccbGrid({ mccbList, getBorrowedCount, onSelectCard }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
      {mccbList.map((mccb) => (
        <MccbCard
          key={mccb.id}
          mccb={mccb}
          borrowedCount={getBorrowedCount(mccb)}
          onSelect={() => onSelectCard(mccb)}
        />
      ))}
    </div>
  );
}