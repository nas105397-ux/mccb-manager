import { useState } from 'react';
import { useMccbData } from './hooks/useMccbData';
import Header from './components/Header';
import AdminPanel from './components/AdminPanel';
import MccbCard from './components/MccbCard';
import ControlModal from './components/ControlModal';
import RequestFormPanel from './components/RequestFormPanel';
import RequestListPanel from './components/RequestListPanel';
import DashboardView from './components/DashboardView';

export default function App() {
  const {
    mccbList, rooms, categories, updateMccb, saveMccbEntry, deleteMccb,
    importFromCSV, getBorrowedCount, addRoom, updateRoom, deleteRoom,
    addCategory, updateCategory, deleteCategory,
    requests, addRequest, deleteRequest,
    logs, logSettings, changeMaxLogSize, clearAllLogs,
    // 💡 グループ情報を抽出
    deviceGroups, addDeviceGroup, updateDeviceGroup, deleteDeviceGroup 
  } = useMccbData();

  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('すべて');
  const [filterRoom, setFilterRoom] = useState('すべて');
  const [filterFavorite, setFilterFavorite] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false); // 🔓 管理者状態
  const [selectedMccbId, setSelectedMccbId] = useState(null);
  
  const [activeTab, setActiveTab] = useState('dashboard');

  // 💡 【新設】管理者モード切替時のパスワード認証チェック関数
  const handleToggleAdmin = () => {
    if (!isAdmin) {
      // 一般 ➔ 管理者へ切り替える時だけパスワードを要求
      const password = window.prompt('管理者パスワードを入力してください：');
      if (password === 'admin') {
        setIsAdmin(true);
        alert('🔓 管理者認証に成功しました。');
      } else if (password !== null) {
        alert('❌ パスワードが正しくありません。認証に失敗しました。');
      }
    } else {
      // 管理者 ➔ 一般へ戻る時はパスワード確認なしで即座に安全解除
      setIsAdmin(false);
    }
  };

  const filteredMccbList = mccbList.filter((mccb) => {
    const matchesSearch = mccb.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRoom = filterRoom === 'すべて' || mccb.room === filterRoom;
    const matchesStatus =
      filterStatus === 'すべて' ||
      (filterStatus === '送電中' && !mccb.isPowerOff) ||
      (filterStatus === '停電中' && mccb.isPowerOff);
    const matchesFavorite = !filterFavorite || mccb.isFavorite;
    return matchesSearch && matchesRoom && matchesStatus && matchesFavorite;
  });

  const currentMccb = mccbList.find((m) => m.id === selectedMccbId);

  if (activeTab === 'monitor') {
    return (
      <div className="relative">
        <button
          onClick={() => setActiveTab('dashboard')}
          className="absolute top-4 right-44 z-50 bg-gray-800 hover:bg-gray-700 text-white font-bold px-4 py-2 rounded-xl text-xs border border-gray-700 shadow-lg cursor-pointer transition-all"
        >
          ↩️ 監視モードを終了
        </button>
        <DashboardView />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 text-gray-855 p-4 font-sans print:p-0 print:bg-white">
      <div className="max-w-7xl mx-auto space-y-4 print:space-y-0">
        
        {/* 📑 タブメニュー */}
        <div className="flex justify-between items-center bg-white p-2 rounded-xl border border-gray-200 shadow-sm print:hidden">
          <div className="flex flex-wrap gap-2">
            <button onClick={() => setActiveTab('dashboard')} className={`px-4 py-2 rounded-lg text-xs font-black transition-all cursor-pointer ${ activeTab === 'dashboard' ? 'bg-blue-600 text-white shadow-md' : 'text-gray-500 hover:bg-gray-100' }`}>🎛️ 札管理ダッシュボード</button>
            <button onClick={() => setActiveTab('request')} className={`px-4 py-2 rounded-lg text-xs font-black transition-all cursor-pointer ${ activeTab === 'request' ? 'bg-blue-600 text-white shadow-md' : 'text-gray-500 hover:bg-gray-100' }`}>🖨️ 停電作業 依頼発行・印刷</button>
            <button onClick={() => setActiveTab('requestList')} className={`px-4 py-2 rounded-lg text-xs font-black transition-all cursor-pointer ${ activeTab === 'requestList' ? 'bg-blue-600 text-white shadow-md' : 'text-gray-500 hover:bg-gray-100' }`}>📋 依頼一覧・進捗 ({requests.length})</button>
            <button onClick={() => setActiveTab('monitor')} className="px-4 py-2 rounded-lg text-xs font-black text-teal-600 border border-teal-200 bg-teal-50 hover:bg-teal-100 transition-all cursor-pointer shadow-sm flex items-center gap-1">📺 電気室モニター</button>
          </div>
          {/* 💡 差し替えポイント: onClick を認証チェック関数 handleToggleAdmin へ変更 */}
          <button onClick={handleToggleAdmin} className={`px-3 py-1.5 rounded-lg text-[11px] font-black tracking-wide border cursor-pointer shadow-sm transition-all whitespace-nowrap mr-1 ${ isAdmin ? 'bg-amber-50 border-amber-300 text-amber-700 hover:bg-amber-100' : 'bg-gray-50 border-gray-300 text-gray-500 hover:bg-gray-100' }`}>
            {isAdmin ? '🔓 モード: 管理者（フルアクセス）' : '🔒 モード: 一般ユーザー（制限版）'}
          </button>
        </div>

        {/* 🎛️ 札管理ダッシュボード */}
        {activeTab === 'dashboard' && (
          <>
            <Header
              searchTerm={searchTerm} setSearchTerm={setSearchTerm} filterStatus={filterStatus} setFilterStatus={setFilterStatus} filterRoom={filterRoom} setFilterRoom={setFilterRoom} filterFavorite={filterFavorite} setFilterFavorite={setFilterFavorite}
              totalCount={mccbList.length} offCount={mccbList.filter(m => m.isPowerOff).length} onCount={mccbList.filter(m => !m.isPowerOff).length} isAdmin={isAdmin} setIsAdmin={setIsAdmin} rooms={rooms}
            />

            {isAdmin && (
              <AdminPanel 
                onImportCSV={importFromCSV} onSaveEntry={saveMccbEntry} mccbList={mccbList} rooms={rooms} categories={categories}
                addRoom={addRoom} updateRoom={updateRoom} deleteRoom={deleteRoom} addCategory={addCategory} updateCategory={updateCategory} deleteCategory={deleteCategory}
                logs={logs} logSettings={logSettings} onChangeMaxLogSize={changeMaxLogSize} onClearAllLogs={clearAllLogs}
                deviceGroups={deviceGroups} addDeviceGroup={addDeviceGroup} updateDeviceGroup={updateDeviceGroup} deleteDeviceGroup={deleteDeviceGroup}
              />
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mt-4">
              {filteredMccbList.map((mccb) => {
                let dynamicMccb = { ...mccb };
                requests.forEach(req => {
                  if (req.reservedCards) {
                    Object.keys(req.reservedCards).forEach(originalId => {
                      const resInfo = req.reservedCards[originalId];
                      if (resInfo && resInfo.actualMccbId === mccb.id) {
                        if (originalId !== mccb.id) {
                          const originalMccb = mccbList.find(m => m.id === originalId);
                          if (originalMccb) dynamicMccb.name = `${mccb.name} (${originalMccb.name})`;
                        } else if (resInfo.customDummyName) {
                          dynamicMccb.name = `${mccb.name} (${resInfo.customDummyName})`;
                        }
                      }
                    });
                  }
                });
                return (
                  <MccbCard key={mccb.id} mccb={dynamicMccb} borrowedCount={getBorrowedCount(mccb)} onSelect={() => setSelectedMccbId(mccb.id)} onToggleFavorite={() => updateMccb({ ...mccb, isFavorite: !mccb.isFavorite })} requests={requests} />
                );
              })}
            </div>

            {currentMccb && (
              <ControlModal mccb={currentMccb} borrowedCount={getBorrowedCount(currentMccb)} onClose={() => setSelectedMccbId(null)} onUpdate={updateMccb} onDelete={deleteMccb} isAdmin={isAdmin} rooms={rooms} categories={categories} />
            )}
          </>
        )}

        {/* 📝 停電作業 依頼発行 */}
        {activeTab === 'request' && (
          <RequestFormPanel mccbList={mccbList} onAddRequest={addRequest} requests={requests} deviceGroups={deviceGroups} />
        )}

        {activeTab === 'requestList' && (
          <RequestListPanel requests={requests} mccbList={mccbList} onDeleteRequest={deleteRequest} />
        )}

      </div>
    </div>
  );
}